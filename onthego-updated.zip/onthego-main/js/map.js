// Map Module - Handles Leaflet map initialization and markers
const MapModule = {
    map: null,
    markers: [],
    userMarker: null,
    userLocation: null,
    searchAreaBtn: null,

    /**
     * Initialize the map
     */
    init() {
        // Check if Leaflet is available
        if (typeof L === 'undefined') {
            console.warn('Leaflet library not loaded. Map functionality disabled.');
            // No map available; fall back to default coordinates for the list
            this.userLocation = { lat: CONFIG.DEFAULT_LAT, lng: CONFIG.DEFAULT_LNG };
            if (window.App && window.App.onLocationReady) {
                window.App.onLocationReady(CONFIG.DEFAULT_LAT, CONFIG.DEFAULT_LNG);
            }
            return;
        }

        // Create map centered on default location
        this.map = L.map('map').setView(
            [CONFIG.DEFAULT_LAT, CONFIG.DEFAULT_LNG],
            CONFIG.DEFAULT_ZOOM
        );

        // Add Esri satellite tiles for Google Earth-style satellite view
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
            maxZoom: 19
        }).addTo(this.map);

        // Add "Search This Area" button
        this.addSearchAreaButton();

        // Listen for map move to show search area button
        this.map.on('moveend', () => {
            if (this.searchAreaBtn) {
                this.searchAreaBtn.style.display = 'block';
            }
        });

        // NOTE: We do not auto-request GPS on load.
        // Location is set via Trip/Hotel selector or the "Use My Location" button.
    },

    /**
     * Add a "Search This Area" button overlay on the map
     */
    addSearchAreaButton() {
        if (!this.map) return;

        const SearchAreaControl = L.Control.extend({
            options: { position: 'topright' },
            onAdd: () => {
                const btn = L.DomUtil.create('button', 'search-area-btn');
                btn.innerHTML = '<i class="fas fa-search-location"></i> Search This Area';
                btn.style.display = 'none';
                btn.onclick = (e) => {
                    L.DomEvent.stopPropagation(e);
                    this.searchCurrentArea();
                    btn.style.display = 'none';
                };
                L.DomEvent.disableClickPropagation(btn);
                this.searchAreaBtn = btn;
                return btn;
            }
        });

        this.map.addControl(new SearchAreaControl());
    },

    /**
     * Set the active search center (Trip/Hotel or GPS) without auto-requesting permissions.
     * This will also trigger a restaurant search at that location.
     * @param {number} lat
     * @param {number} lng
     * @param {string} label
     */
    setSearchCenter(lat, lng, label = 'Search Center') {
        this.userLocation = { lat, lng };

        if (this.map) {
            this.map.setView([lat, lng], CONFIG.DEFAULT_ZOOM);
        }

        this.addUserMarker(lat, lng, label);

        // Trigger list + markers refresh
        if (window.App && window.App.onLocationReady) {
            window.App.onLocationReady(lat, lng);
        }
    },

    /**
     * Request live GPS location only when the user explicitly asks.
     */
    requestUserLocation() {
        if (!('geolocation' in navigator)) {
            console.log('Geolocation not supported');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                this.setSearchCenter(lat, lng, 'My Location');
            },
            (error) => {
                console.error('Geolocation error:', error);
                this.handleGeolocationError(error);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    },

    /**
     * Search for restaurants in the current map view area
     */
    async searchCurrentArea() {
        const center = this.map.getCenter();
        const lat = center.lat;
        const lng = center.lng;

        console.log(`Searching area at: ${lat}, ${lng}`);

        try {
            const restaurants = await API.fetchRestaurants(lat, lng);
            console.log(`Found ${restaurants.length} restaurants in area`);
            UI.setRestaurants(restaurants);
        } catch (error) {
            console.error('Error searching area:', error);
        }
    },

    /**
     * Get user's current location using Geolocation API
     */
    getUserLocation() {
        if ('geolocation' in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.userLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    
                    // Center map on user location
                    if (this.map) {
                        this.map.setView([this.userLocation.lat, this.userLocation.lng], CONFIG.DEFAULT_ZOOM);
                    }
                    
                    // Add user location marker
                    this.addUserMarker(this.userLocation.lat, this.userLocation.lng);
                    
                    // Notify app that location is ready
                    if (window.App && window.App.onLocationReady) {
                        window.App.onLocationReady(this.userLocation.lat, this.userLocation.lng);
                    }
                },
                (error) => {
                    console.error('Geolocation error:', error);
                    this.handleGeolocationError(error);
                    
                    // Use default location
                    this.userLocation = {
                        lat: CONFIG.DEFAULT_LAT,
                        lng: CONFIG.DEFAULT_LNG
                    };
                    
                    // Notify app with default location
                    if (window.App && window.App.onLocationReady) {
                        window.App.onLocationReady(CONFIG.DEFAULT_LAT, CONFIG.DEFAULT_LNG);
                    }
                },
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        } else {
            console.log('Geolocation not supported');
            this.userLocation = {
                lat: CONFIG.DEFAULT_LAT,
                lng: CONFIG.DEFAULT_LNG
            };
            
            // Notify app with default location
            if (window.App && window.App.onLocationReady) {
                window.App.onLocationReady(CONFIG.DEFAULT_LAT, CONFIG.DEFAULT_LNG);
            }
        }
    },

    /**
     * Handle geolocation errors
     * @param {Object} error - Geolocation error object
     */
    handleGeolocationError(error) {
        let message = 'Unable to get your location. ';
        
        switch(error.code) {
            case error.PERMISSION_DENIED:
                message += 'Location permission denied. Using default location (San Francisco).';
                break;
            case error.POSITION_UNAVAILABLE:
                message += 'Location information unavailable. Using default location.';
                break;
            case error.TIMEOUT:
                message += 'Location request timed out. Using default location.';
                break;
            default:
                message += 'Using default location.';
        }
        
        console.log(message);
    },

    /**
     * Add user location marker to map
     * @param {number} lat - Latitude
     * @param {number} lng - Longitude
     * @param {string} label - Popup label
     */
    addUserMarker(lat, lng, label = 'Your Location') {
        if (!this.map || typeof L === 'undefined') return;

        // Remove previous marker if any
        if (this.userMarker) {
            try { this.map.removeLayer(this.userMarker); } catch (e) {}
        }

        // Create custom icon for user/search center
        const userIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        this.userMarker = L.marker([lat, lng], { icon: userIcon })
            .addTo(this.map)
            .bindPopup(`<strong>${label}</strong>`);
    },


    /**
     * Clear all restaurant markers
     */
    clearMarkers() {
        this.markers.forEach(marker => {
            this.map.removeLayer(marker);
        });
        this.markers = [];
    },

    /**
     * Add restaurant markers to map
     * @param {Array} restaurants - Array of restaurant objects
     */
    addRestaurantMarkers(restaurants) {
        if (!this.map || typeof L === 'undefined') return;
        
        this.clearMarkers();

        restaurants.forEach(restaurant => {
            const marker = this.createRestaurantMarker(restaurant);
            this.markers.push(marker);
        });

        // Fit map to show all markers if there are any
        if (this.markers.length > 0) {
            const layers = [...this.markers];
            if (this.userMarker) layers.push(this.userMarker);
            if (layers.length > 0) {
                const group = L.featureGroup(layers);
                this.map.fitBounds(group.getBounds().pad(0.1));
            }
        }
    },

    /**
     * Create a marker for a restaurant
     * @param {Object} restaurant - Restaurant object
     * @returns {Object} - Leaflet marker object
     */
    createRestaurantMarker(restaurant) {
        if (!this.map || typeof L === 'undefined') return null;
        
        const lat = restaurant.coordinates.latitude;
        const lng = restaurant.coordinates.longitude;

        // Create custom icon for restaurant
        const restaurantIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // Create popup content matching the restaurant list card format
        const popupContent = this.createPopupContent(restaurant);

        // Create and return marker
        const marker = L.marker([lat, lng], { icon: restaurantIcon })
            .addTo(this.map)
            .bindPopup(popupContent, { maxWidth: 350, minWidth: 280 });

        // Add click event to highlight corresponding card
        marker.on('click', () => {
            if (window.UI && window.UI.highlightRestaurantCard) {
                window.UI.highlightRestaurantCard(restaurant.id);
            }
        });

        return marker;
    },

    /**
     * Create popup content for a restaurant marker that mimics the restaurant list cards
     * @param {Object} restaurant - Restaurant object
     * @returns {string} - HTML string for popup
     */
    createPopupContent(restaurant) {
        const categories = restaurant.categories
            ? restaurant.categories.map(cat => cat.title).join(', ')
            : '';
        
        const stars = API.getStarRating(restaurant.rating);

        const location = restaurant.location;
        const address = location 
            ? `${location.address1}, ${location.city}, ${location.state} ${location.zip_code}`
            : '';

        const tagsHtml = restaurant.tags && restaurant.tags.length > 0 
            ? `<div class="popup-tags">${restaurant.tags.map(tag => {
                const tagClassMap = {
                    'Good for Business Meal': 'business',
                    'Chill': 'chill',
                    'Fun': 'fun',
                    'Local Spots': 'local',
                    'Nightlife': 'fun',
                    'Craft Beer': 'chill'
                };
                const tagClass = tagClassMap[tag] || tag.toLowerCase().replace(/\s+/g, '-');
                return `<span class="tag-badge ${tagClass}">${tag}</span>`;
            }).join('')}</div>`
            : '';

        const deliveryLinks = API.getDeliveryLinks(restaurant.name, address);
        const reservationLinks = API.getReservationLinks(
            restaurant.name, 
            location ? location.city : ''
        );
        const socialLinks = API.getSocialMediaLinks(restaurant.name);

        return `
            <div class="popup-content popup-content-full">
                <div class="popup-header">
                    <div>
                        <div class="popup-name">${restaurant.name}</div>
                        <div style="color: #666; font-size: 0.85rem;">${categories}</div>
                    </div>
                    ${restaurant.image_url ? `<img src="${restaurant.image_url}" alt="${restaurant.name}" class="popup-image">` : ''}
                </div>
                <div class="popup-rating">
                    <span class="stars">${stars}</span>
                    <span class="rating-number">${restaurant.rating}</span>
                    <span class="review-count">(${restaurant.review_count} reviews)</span>
                    ${restaurant.visited ? '<span class="visited-indicator" style="font-size:0.7rem;padding:0.2rem 0.4rem;margin-left:0.3rem;"><i class="fas fa-check"></i> Visited</span>' : ''}
                </div>
                <div class="popup-info">
                    <span><i class="fas fa-dollar-sign" style="color:var(--primary-color)"></i> ${restaurant.price || 'N/A'}</span>
                    <span><i class="fas fa-walking" style="color:var(--primary-color)"></i> ${API.formatDistance(restaurant.distance)}</span>
                    ${restaurant.display_phone ? `<span><i class="fas fa-phone" style="color:var(--primary-color)"></i> ${restaurant.display_phone}</span>` : ''}
                </div>
                ${tagsHtml}
                <div style="font-size: 0.8rem; color: #666; margin-bottom: 0.5rem;">
                    <i class="fas fa-map-marker-alt" style="color:var(--primary-color)"></i> ${address}
                </div>
                <div class="popup-actions">
                    <a href="${restaurant.url}" target="_blank" rel="noopener noreferrer" class="popup-btn" style="background-color:#D32323;">
                        <i class="fab fa-yelp"></i> Yelp
                    </a>
                    <a href="${deliveryLinks.ubereats}" target="_blank" rel="noopener noreferrer" class="popup-btn">
                        <i class="fas fa-hamburger"></i> Uber Eats
                    </a>
                    <a href="${deliveryLinks.doordash}" target="_blank" rel="noopener noreferrer" class="popup-btn">
                        <i class="fas fa-motorcycle"></i> DoorDash
                    </a>
                    <a href="${reservationLinks.opentable}" target="_blank" rel="noopener noreferrer" class="popup-btn">
                        <i class="fas fa-calendar-check"></i> OpenTable
                    </a>
                </div>
                <div class="popup-social-links">
                    <a href="${socialLinks.instagram}" target="_blank" rel="noopener noreferrer" class="social-link instagram" title="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="${socialLinks.facebook}" target="_blank" rel="noopener noreferrer" class="social-link facebook" title="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="${socialLinks.twitter}" target="_blank" rel="noopener noreferrer" class="social-link twitter" title="Twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                </div>
            </div>
        `;
    },

    /**
     * Pan map to a specific restaurant
     * @param {number} lat - Latitude
     * @param {number} lng - Longitude
     */
    panToRestaurant(lat, lng) {
        if (!this.map) return;
        
        this.map.setView([lat, lng], 16, {
            animate: true,
            duration: 0.5
        });
    },

    /**
     * Open popup for a specific marker
     * @param {string} restaurantId - Restaurant ID
     * @param {Array} restaurants - Array of restaurant objects
     */
    openMarkerPopup(restaurantId, restaurants) {
        const restaurant = restaurants.find(r => r.id === restaurantId);
        if (!restaurant) return;

        const markerIndex = restaurants.indexOf(restaurant);
        if (markerIndex >= 0 && markerIndex < this.markers.length) {
            const marker = this.markers[markerIndex];
            marker.openPopup();
            this.panToRestaurant(
                restaurant.coordinates.latitude,
                restaurant.coordinates.longitude
            );
        }
    }
};
