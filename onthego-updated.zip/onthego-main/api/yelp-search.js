// Vercel Serverless Function: /api/yelp-search
// Proxies Yelp Fusion API so the client never sees the API key.

module.exports = async function handler(req, res) {
  try {
    const apiKey = process.env.YELP_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'YELP_API_KEY not configured on the server.' });
    }

    const q = req.query || {};
    const latitude = q.latitude;
    const longitude = q.longitude;

    if (!latitude || !longitude) {
      return res.status(400).json({ error: 'Missing required query params: latitude, longitude' });
    }

    const params = new URLSearchParams({
      latitude: String(latitude),
      longitude: String(longitude),
      radius: String(q.radius || '8047'),
      limit: String(q.limit || '20'),
      categories: String(q.categories || 'restaurants'),
      sort_by: String(q.sort_by || 'rating')
    });

    if (q.term) params.set('term', String(q.term));

    const url = `https://api.yelp.com/v3/businesses/search?${params.toString()}`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/json'
      }
    });

    const data = await response.json().catch(() => null);

    // Cache on Vercel edge a bit (tune later)
    res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');

    if (!response.ok) {
      return res.status(response.status).json(data || { error: 'Yelp API request failed.' });
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('yelp-search error', err);
    return res.status(500).json({ error: 'Server error while calling Yelp.' });
  }
};
